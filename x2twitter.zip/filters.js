// フィルターワード定義（X to Twitter 2）
// content.js より分離。content_scripts で filters.js → content.js の順に読み込む。

// ===== ネガティブ判定ワード（強/弱シグナル＋例外）=====
const EN = w => `\\b${w}\\b`;
const STRONG_JP = [
  "政治", "国際政治", "世界政治", "国政", "政局", "総理", "首相", "選挙", "国会", "衆議院", "参議院",
  "自民党", "立憲民主党", "国民民主党", "共産党", "日本維新", "公明党", "与党", "野党", "政権",
  "内閣", "閣僚", "大臣", "法案", "予算案", "解散", "増税", "減税", "消費税", "防衛費",
  "支持率", "不支持率", "党首", "代表選", "官房長官", "首脳会談", "閣僚会談", "党首会談",
  "岸田", "石破", "安倍", "菅", "河野", "高市", "小泉", "玉木", "馬場", "野田", "泉",
  "知事選", "衆院選", "参院選", "衆院", "参院", "地方選", "投開票", "開票", "投票率",
  "争点", "街頭演説", "政見", "補正予算", "政権交代", "デモ", "抗議", "ストライキ",
  "スキャンダル", "汚職", "贈収賄", "脱税", "偽造", "横領", "背任", "インサイダー",
  "陰謀論", "反ワク", "デマ", "フェイク", "捏造", "隠蔽", "メディア支配",
  "情報操作", "プロパガンダ", "グレートリセット", "世界新秩序", "Qアノン", "マイクロチップ",
  "戦争", "戦闘", "侵攻", "攻撃", "ミサイル", "爆撃", "空爆", "砲撃", "報復", "ドローン",
  "軍事", "兵士", "部隊", "紛争", "停戦", "ウクライナ", "ロシア", "プーチン", "ガザ",
  "パレスチナ", "イスラエル", "ハマス", "ヒズボラ", "イラン", "北朝鮮", "核実験",
  "自衛隊", "戦線", "前線", "戦場", "占領", "侵略", "テロ", "テロリスト",
  "習近平", "金正恩", "ネタニヤフ", "ゼレンスキー", "マクロン", "モディ", "エルドアン",
  "中国共産党", "火災", "火事", "出火", "焼失", "炎上", "爆発", "爆発物",
  "交通事故", "事故死", "死亡事故", "人身事故", "事故", "衝突", "追突", "転落", "崩落", "墜落",
  "死亡", "死者", "亡くなり", "亡くなった", "逝去", "訃報", "死傷者", "負傷", "重体",
  "重症", "重傷", "けが", "怪我", "行方不明", "失踪", "自殺", "自殺未遂", "殺人", "殺害",
  "事件", "犯罪", "強盗", "詐欺", "窃盗", "盗難", "密輸", "麻薬", "人身売買",
  "逮捕", "勾留", "起訴", "判決", "懲役", "冤罪", "暴力", "暴行", "虐待",
  "性犯罪", "性暴力", "強制わいせつ", "痴漢", "誘拐", "監禁", "脅迫", "恐喝",
  "サイバー攻撃", "ハッキング", "フィッシング", "銃", "銃撃", "発砲", "刃物", "刺傷", "刺殺",
  "いがみ合い", "いがみあい", "対立", "争い", "喧嘩", "口論", "誹謗中傷", "中傷", "罵倒",
  "侮辱", "嘲笑", "叩き", "大炎上", "敵対", "反目", "内紛", "派閥争い", "分裂",
  "いじめ", "嫌がらせ", "セクハラ", "パワハラ", "モラハラ",
  "犠牲", "悲報", "悲劇", "哀悼", "追悼", "遺体", "遺族", "心肺停止", "救急搬送",
  "津波", "地震", "震災", "台風", "豪雨", "大雨", "記録的豪雨", "河川氾濫", "高潮",
  "洪水", "土砂災害", "地滑り", "噴火", "火山噴火", "竜巻", "大雪", "熱波", "寒波",
  "停電", "断水", "コロナ", "感染者", "感染拡大", "避難指示", "避難所",
  "倒産", "解雇", "リストラ", "不況", "不景気", "物価高", "円安",
  "食中毒", "熱中症", "猛暑", "鳥インフル", "インフル",
  "反AI", "AI規制", "AI禁止", "AI反対", "AI崩壊", "AI消滅", "AI支配", "AIの暴走", "AI暴走",
  "AI戦争", "AI兵器", "AI犯罪", "AIに仕事を奪われる", "AIで失業", "AI大量失業", "人工知能の暴走",
  "シンギュラリティ", "ロボットに支配", "ディープフェイク", "なりすまし動画", "偽動画", "偽音声",
  "AI論争", "AI議論", "AI絵", "AIイラスト", "AIアート", "AI生成", "AI生成物", "生成AI", "生成系AI",
  "AIパクリ", "AI盗作", "AI盗用", "無断学習", "AIの是非", "AIをめぐる", "AIを巡る", "AI反対派", "AI賛成派", "画像生成AI",
  "扇動", "煽動", "焚きつけ", "焚き付け", "危機を煽る", "不安を煽る", "恐怖を煽る", "パニックを煽る",
  "過激化", "過激派", "デマ拡散", "情報戦", "洗脳", "洗脳される", "誤情報", "虚偽情報", "偽情報",
  "激怒", "怒り心頭", "怒り狂う", "殺意", "殺意を抱く", "憎悪", "憎しみ", "嫌悪感", "吐き気がする",
  "ブチ切れ", "ブチギレ", "キレた", "切れた", "頭に来る", "頭にきた", "許せない", "許すまじ",
  "復讐", "復讐を誓う", "恨み", "敵意", "軽蔑", "侮蔑", "見下し", "見下す", "マウント", "マウンティング",
  "アフガニスタン", "イラク", "シリア", "イエメン", "スーダン", "リビア", "ソマリア",
  "ミャンマー", "レバノン", "ベネズエラ", "ベラルーシ", "アルメニア", "アゼルバイジャン",
  "カシミール", "エチオピア", "コンゴ", "ハイチ", "台湾", "南シナ海",
  "NAFO", "ナフォ", "フェラ軍",
  "ワシントン", "ジェファーソン", "リンカーン", "ルーズベルト", "ケネディ", "ニクソン",
  "レーガン", "クリントン", "オバマ", "トランプ", "バイデン", "ブッシュ", "ジョンソン",
  "トルーマン", "アイゼンハワー", "アダムズ", "マディソン", "モンロー", "ジャクソン",
  "バンビューレン", "ハリソン", "テイラー", "フィルモア", "ピアース", "ブキャナン",
  "グラント", "ヘイズ", "ガーフィールド", "アーサー", "クリーブランド", "マッキンリー",
  "タフト", "ウィルソン", "ハーディング", "クーリッジ", "フーヴァー", "フォード", "カーター",
  "スターリン", "レーニン", "毛沢東", "ヒトラー", "チャーチル", "サッチャー", "ゴルバチョフ",
  "エリツィン", "ムバラク", "カダフィ", "サダム", "ビンラディン", "チャベス", "カストロ",
  "マドゥロ", "ルーラ", "ボルソナロ", "トルドー", "スターマー", "スナク", "ショルツ",
  "メルケル", "メローニ", "ムッソリーニ", "フランコ", "サンチェス", "サルコジ", "シラク",
  "ドゴール", "ルカシェンコ", "アサド", "金日成", "金正日", "蒋介石", "マンデラ", "ガンジー",
  "ナポレオン", "カエサル",
  "為替", "為替介入", "為替相場", "円相場", "円高", "日米", "日露", "日韓",
  "米国", "米軍", "米政府", "米大統領", "米中",
  "露軍", "露政府", "露大統領", "仏軍", "仏政府", "仏大統領",
  "英軍", "英政府", "英首相", "独軍", "独政府", "独首相",
  "中国政府", "中国軍",
  "不正アクセス", "個人情報流出", "個人情報漏洩", "情報漏洩", "情報漏えい", "データ流出", "データ漏えい", "なりすまし",
  "殺人事件", "無差別殺傷", "通り魔", "猟奇殺人",
  "ひき逃げ", "はねられた", "飲酒運転", "酒気帯び", "あおり運転", "逆走", "無免許運転", "暴走行為"
];
const STRONG_EN = [
  "politics", "political", "politician", "election", "president", "presidential",
  "campaign", "vote", "voting", "congress", "senate", "senator", "parliament",
  "parliamentarian", "prime minister", "premier", "chancellor", "cabinet", "minister",
  "lawmaker", "lawmakers", "legislation", "government", "democrat", "republican",
  "maga", "trump", "biden", "impeachment", "scandal", "corruption", "corrupt",
  "bribery", "bribe", "coup", "regime", "authoritarian", "dictatorship", "dictator",
  "sanction", "sanctions", "tariff", "tariffs", "trade war", "nato", "summit", "treaty",
  "diplomacy", "diplomatic", "geopolitical", "border", "immigrant", "immigration",
  "deportation", "shooting", "shooter", "gunman", "killed", "killing", "kills",
  "death", "deaths", "dead", "died", "dying", "murder", "massacre", "terrorist",
  "terrorism", "attack", "attacks", "bombing", "bomb", "explosion", "explosive",
  "wildfire",
  "crash", "accident", "accidents", "injured", "injury",
  "victim", "victims", "suicide", "protest", "riots", "riot", "war", "wars",
  "military", "soldier", "soldiers", "troops", "invasion", "occupation", "annexation",
  "missile", "missiles", "nuclear", "ceasefire", "ukraine", "russia", "putin",
  "gaza", "palestine", "israel", "hamas", "iran", "isis", "taliban", "xi jinping",
  "kim jong un", "netanyahu", "zelensky", "macron", "modi", "erdogan",
  "deep state", "new world order", "conspiracy", "conspiracy theory", "false flag",
  "rigged", "stolen election", "fake news", "propaganda", "censorship",
  "airstrike", "air strike", "artillery", "bombardment", "insurgent", "militant",
  "extremism", "radicalization", "inflation", "recession", "layoff", "layoffs",
  "bankruptcy", "unemployment", "earthquake", "flood", "floods", "hurricane",
  "tornado", "storm", "blizzard", "heat wave", "cold snap", "volcano", "volcanic",
  "tsunami", "landslide", "mudslide", "typhoon", "cyclone", "drought", "famine",
  "hostage", "kidnap", "kidnapping", "rape", "abuse", "arson",
  "theft", "robbery", "burglary", "fraud", "scam", "scammer", "embezzlement",
  "trafficking", "smuggling", "drugs", "narcotics", "ransomware", "phishing",
  "hacking", "cyberattack", "cyber attack", "casualties", "casualty", "fatality", "fatalities",
  "argument", "arguments", "arguing", "quarrel", "feud", "feuding", "hostility",
  "hostile", "toxic", "trolling", "trolls", "harassment", "cyberbullying", "bullying",
  "insult", "insults", "mocking", "ridicule", "hatred", "hate speech", "bigotry",
  "racism", "xenophobia", "misogyny", "homophobia", "discrimination",
  "artificial intelligence", "AI takeover", "AI apocalypse", "AI doom", "robot uprising",
  "singularity", "killer robots", "autonomous weapons", "AI weapons", "deepfake", "deepfakes",
  "AI replacing jobs", "AI job losses", "AI layoffs", "AI ban", "ban AI", "AI regulation",
  "AI art", "AI-generated", "generative AI", "AI image", "AI images", "AI illustration",
  "AI debate", "AI controversy", "AI art debate", "AI art controversy", "AI stealing",
  "AI theft", "AI copyright", "AI lawsuit", "AI generated art", "AI art theft", "AI critics",
  "ChatGPT controversy", "GPT debate",
  "incite", "incites", "inciting", "incitement", "fearmongering", "scaremongering", "hysteria",
  "misinformation", "disinformation", "brainwashing", "smear campaign", "hate campaign", "mob mentality",
  "rage", "furious", "fury", "enraged", "livid", "seething", "murderous", "despise", "despised",
  "contempt", "loathing", "loathe", "disgusting", "revolting", "repulsive", "vile", "revenge",
  "vendetta", "grudge", "animosity", "condescending", "patronizing", "smug",
  "international politics", "world politics", "political situation", "political instability",
  "national diet", "house of representatives", "house of councillors", "ldp",
  "liberal democratic party", "constitutional democratic party", "japanese communist party",
  "communist party", "komeito", "nippon ishin", "ruling party", "opposition party",
  "opposition parties", "administration", "bill", "bills", "budget bill", "budget proposal",
  "dissolution", "dissolve parliament", "tax increase", "tax hike", "tax hikes", "tax cut",
  "tax cuts", "consumption tax", "defense budget", "approval rating", "approval ratings",
  "disapproval rating", "party leader", "leadership election", "leadership race",
  "chief cabinet secretary", "kishida", "ishiba", "abe", "suga", "kono", "takaichi",
  "koizumi", "tamaki", "baba", "noda", "izumi", "gubernatorial election",
  "lower house election", "upper house election", "local election", "local elections",
  "vote counting", "voter turnout", "campaign rally", "campaign rallies",
  "supplementary budget", "change of government", "power transfer", "labor strike",
  "tax evasion", "tax fraud", "forgery", "counterfeit",
  "breach of trust", "insider trading", "great reset", "qanon", "q anon", "microchip",
  "microchips",     "antivax", "anti-vax",
  "fabrication", "fabricated", "cover-up", "coverup", "media control", "media manipulation",
  "information manipulation", "battle", "combat", "shelling", "retaliation", "drone",
  "drones", "drone strike", "hezbollah", "north korea",
  "north korean", "nuclear test", "nuclear testing", "self defense forces", "jsdf",
  "front line", "frontline", "battlefield", "chinese communist party", "ccp",
  "traffic accident", "car accident", "vehicle accident", "accidental death",
  "fatal accident", "deadly accident", "collision", "collide", "plunge", "plunged",
  "fell off", "collapse", "collapsed", "passed away", "obituary", "obituaries",
  "critical condition", "critically injured", "serious injury", "seriously injured",
  "missing", "missing person", "disappeared", "suicide attempt", "attempted suicide",
  "incident", "incidents", "crime", "crimes", "criminal", "arrest", "arrested",
  "arrests", "detained", "indictment", "indicted", "verdict", "imprisonment",
  "prison sentence", "wrongful conviction", "violence", "violent", "assault",
  "assaulted", "sex crime", "sexual violence", "sexual assault", "groping", "groped",
  "held captive", "threat", "threats", "threatening", "intimidation", "blackmail",
  "extortion", "gun", "guns", "firearm", "firearms", "gunfire", "shots fired",
  "opened fire", "knife", "knife attack", "stabbing", "stabbed", "heavy rain",
  "torrential rain", "downpour", "record rainfall", "river overflow", "storm surge",
  "eruption", "erupted", "heavy snow", "snowstorm", "power outage", "blackout",
  "water outage", "covid", "covid-19", "coronavirus", "infection", "infections",
  "outbreak", "evacuation order",     "evacuation", "evacuated", "downsizing",
  "economic downturn", "downturn", "rising prices", "soaring prices", "price hikes",
  "weak yen", "food poisoning", "heatstroke", "heat stroke", "extreme heat",
  "scorching heat", "bird flu", "avian flu", "influenza", "quarreling",
  "bickering", "confrontation", "standoff", "strife",
  "brawl", "slander", "defamation", "defamatory", "bashing", "slam", "slamming",
  "cancel culture", "antagonism", "infighting", "internal strife", "factional",
  "factionalism", "split", "division", "divided", "schism", "sexual harassment",
  "power harassment", "moral harassment", "sacrifice", "sad news", "tragedy", "tragic",
  "mourning", "grief", "memorial", "dead body", "remains", "bereaved", "cardiac arrest",
  "hospitalized", "rushed to hospital", "against ai", "AI collapse", "AI meltdown",
  "AI extinction", "AI domination", "AI war", "AI crime", "AI unemployment",
  "runaway AI", "impersonation video", "fake video", "fake audio", "provoke",
  "provoking", "stir up", "inciting panic", "spreading fake news", "spreading lies",
  "share disinformation", "information warfare", "false information", "nauseating",
  "sickening", "infuriating", "infuriated", "pissed off", "unforgivable",
  "cannot forgive", "can't forgive", "cant forgive", "won't forgive", "one-up", "one-upping", "look down on",
  "looking down", "snapped", "lost it",
  "afghanistan", "iraq", "syria", "yemen", "sudan", "libya", "somalia", "myanmar",
  "lebanon", "venezuela", "belarus", "armenia", "azerbaijan", "kashmir",
  "ethiopia", "congo", "haiti", "taiwan", "south china sea",
  "nafo", "north atlantic fellas", "fella army",
  "washington", "jefferson", "lincoln", "roosevelt", "kennedy", "nixon", "reagan",
  "clinton", "obama", "bush", "stalin", "lenin", "mao zedong", "mao", "hitler",
  "churchill", "thatcher", "gorbachev", "yeltsin", "mubarak", "gaddafi", "saddam",
  "saddam hussein", "bin laden", "osama bin laden", "chavez", "castro", "maduro",
  "lula", "bolsonaro", "trudeau", "boris johnson", "starmer", "sunak", "scholz",
  "merkel", "meloni", "mussolini", "franco", "sanchez", "sarkozy", "chirac",
  "de gaulle", "lukashenko", "assad", "kim il sung", "kim jong il", "chiang kai shek",
  "mandela", "gandhi", "napoleon", "caesar",
  "exchange rate", "foreign exchange", "fx", "us-china", "us-japan", "japan-us",
  "us military", "us government", "us president",
  "unauthorized access", "data breach", "data leak", "data leaks", "identity theft",
  "hit and run", "drunk driving", "drunk driver", "reckless driving", "road rage",
  "mass stabbing", "random attack", "mass killing"
];
const WEAK_JP = ["論争", "議論", "意見対立", "クレーム", "苦情", "トラブル", "もめ事", "もめごと", "険悪", "ギスギス", "騒動", "不安", "心配", "ストレス", "パニック", "恐慌", "買い占め", "賛否", "賛否両論", "物議", "物議を醸す", "波紋を呼ぶ", "批判殺到", "非難殺到", "反発", "バックラッシュ", "火種", "いざこざ", "ムカつく", "イライラ", "うんざり", "最悪", "呆れた", "嫌い", "怒り", "絶望", "気持ち悪い", "嫌悪", "ゲンナリ", "ドン引き", "モヤモヤ", "ざわつく", "ワクチン", "露", "仏", "韓国"];
const WEAK_EN = ["controversy", "controversial", "dispute", "disputes", "debate", "debates", "complaint", "complaints", "trouble", "friction", "tension", "tensions", "stressed", "stress", "worried", "worry", "panic", "outrage", "uproar", "outcry", "furor", "backlash", "alarm", "annoyed", "annoying", "frustrated", "frustrating", "angry", "mad", "fed up", "sick of", "tired of", "gross", "disgusted", "worst", "despair", "hopeless", "disagreement", "disagreements", "strained", "tense relations", "anxiety", "anxious", "panic buying", "hoarding", "for and against", "mixed reactions", "mixed opinions", "stirring controversy", "causing a stir", "caused a stir", "flood of criticism", "criticized heavily", "squabble", "squabbles", "appalled", "appalling", "dislike", "hate", "anger", "cringe", "cringed", "put off", "uneasy", "unease", "unsettled", "adams", "madison", "monroe", "jackson", "van buren", "harrison", "taylor", "fillmore", "pierce", "buchanan", "grant", "hayes", "garfield", "arthur", "cleveland", "mckinley", "taft", "wilson", "harding", "coolidge", "hoover", "ford", "carter", "truman", "eisenhower", "johnson", "conflict", "conflicts", "fight", "fights", "fighting", "strike", "strikes", "fire", "fires", "shelter", "fake", "flu", "vaccine", "vaccines", "vaccination", "yen", "south korea"];
const JAPAN_SUBJECT_G = new RegExp("(?:日本では|日本人は|日本人が|日本は|日本人|この国は|この国では|japanese people|japanese are|japanese society|japanese government|in japan|japan is|this country)", "gi");

const NEGATIVE_EXCEPT = /(?:火災保険|火災報知器|事故物件|防災|募金|チャリティ|寄付|復興支援|被災地支援|バリアフリー|無事|無傷|全員無事|けがなし|軽傷のみ|助かった|動物|動物園|動物保護|動物好き|ペット|保護犬|保護猫|野良猫|野良犬|子犬|子猫|わんこ|にゃんこ|ワンちゃん|猫ちゃん|犬ちゃん|いぬ|ねこ|うさぎ|ウサギ|ハムスター|金魚|インコ|オウム|パンダ|水族館|アニマル|里親|譲渡会|猫カフェ|ねこカフェ|保護動物|保護活動|犬|猫|鳥|小鳥|カワウソ|フェレット|モルモット|リス|ハリネズミ|カメ|動物の写真|pet|pets|animal|animals|dog|dogs|cat|cats|kitten|kittens|puppy|puppies|bunny|rabbit|hamster|bird|birds|parrot|wildlife|aquarium|panda|foster)/i;
const NEGATIVE_STRONG = new RegExp(`(?:${STRONG_JP.join("|")})|(?:${STRONG_EN.map(EN).join("|")})`, "i");
const NEGATIVE_WEAK_G = new RegExp(`(?:${WEAK_JP.join("|")})|(?:${WEAK_EN.map(EN).join("|")})`, "gi");

// ===== 日本のメディア・新聞社アカウント（ネガティブフィルターの対象外・常に表示）=====
// ハンドル（@ なし・小文字）で判定。追加したければここに追記する
const JP_MEDIA_HANDLES = new Set([
  // 全国紙・経済紙
  "asahi", "asahicom", "yomiuri", "yomiuri_online", "mainichi", "mainichishimbun",
  "nikkei", "nikkei_plus", "nikkei_news", "sankei", "sankei_news", "sankei_express",
  // 通信社
  "kyodo_jp", "kyodonewsjp", "jijicom", "jiji_press", "jiji_koho",
  // NHK
  "nhk_news", "nhk_seikatsu", "nhk_kabun", "nhk_politics", "nhk_sports",
  // 地方紙・ブロック紙
  "tokyoshimbun", "chunichi_web", "doshinweb", "nishinippon", "chugoku_shim",
  "kobeshinbun", "kyoto_np", "kahokushinpo", "shinmai_web", "kumanichi",
  "minaminihon_web", "okinawatimes", "ryukyushimpo", "tokushima_np",
  // テレビ局のニュースアカウント
  "tbs_news", "fnn_news", "nnn_news", "tvtokyo_news", "tv_asahi_news",
  "fujinewsjapan", "nhk_news", "news_tbs", "mbs_news", "cbc_news"
]);
// 表示名（ディスプレイネーム）による補助判定（例: 「◯◯新聞」「◯◯新聞社」）
const JP_MEDIA_NAME = /(?:新聞|新聞社|通信社|放送局|テレビ|NHK|毎日|朝日|読売|日経|産経|共同通信|時事通信|中日|東京新聞|北海道新聞|西日本新聞|中国新聞|神戸新聞|京都新聞|河北新報|信濃毎日|熊本日日|南日本新聞|沖縄タイムス|琉球新報)/;

// ===== 災害支援情報を「見ない」モード =====
// 「災害支援情報を見ない」ON時、およびJev候補抽出に使う災害・救助・支援系キーワード。
// Jev（TypeSafe）が使える場合はこのシグナルを候補ゲート兼フォールバックとして使い、
// 最終判定は content.js が Jev の確率で行う。
const DISASTER_SIGNAL = /(?:地震|余震|震度|震源地|マグニチュード|津波|避難|避難所|避難指示|警報|注意報|特別警報|大雨|洪水|土砂災害|被災地|被災|被害|救助|救助隊|救出|救難|救難支援|安否|安否確認|支援|支援物資|支援金|義援金|被災者支援|募金|ボランティア|ボランティア募集|停電|断水|復旧|復興|災害|熊本|避難場所|避難所開設|受け入れ|連絡先|相談窓口|拡散|拡散希望|共有|シェア|助けて|緊急|お知らせ|情報求む|地震速報|消防|自衛隊|ヘリコプター|earthquake|quake|aftershock|tsunami|evacuation|evacuate|shelter|warning|alert|epicenter|magnitude|flood|landslide|rescue|rescue team|first responders|relief|aid|donation|donate|supplies|volunteer|blackout|outage|recovery|disaster|emergency|urgent|help|share|damage|safety|helpline|hotline)/i;
// 感情をえぐるグラフィック表現（災害情報モードでも非表示を維持）
const DISASTER_EMOTIONAL_BLOCK = /(?:死亡|死者|亡くなり|亡くなった|遺体|犠牲|重体|心肺停止|焼死|圧死|生き埋め|押し流さ|崩れ落ち|死体|遺族|訃報|血|絶望|death|deaths|dead|killed|killing|body|bodies|casualties|fatality|fatalities|trapped|buried|crushed|blood|remains|died|murder)/i;

// ===== グルメ情報を「見ない」モード =====
// 「グルメ情報を見ない」ON時、およびJev候補抽出に使う食べ物・食事系キーワード。
// Jev（TypeSafe）が使える場合はこのシグナルを候補ゲート兼フォールバックとして使い、
// 最終判定は content.js が Jev の確率で行う（食べ物を題材にした絵などを誤判定しない）。
const FOOD_SIGNAL = /(?:ご飯|ごはん|朝ごはん|昼ごはん|夜ごはん|朝食|昼食|夕食|食事|食べ物|食べもの|グルメ|料理|お料理|レシピ|クッキング|ラーメン|そば|うどん|寿司|すし|カレー|ピザ|ハンバーガー|ハンバーグ|パン|ケーキ|スイーツ|お菓子|デザート|アイス|飲み物|ドリンク|コーヒー|ジュース|カフェ|喫茶店|レストラン|居酒屋|焼肉|お好み焼き|たこ焼き|弁当|お弁当|パスタ|サラダ|スープ|味噌汁|おでん|鍋|定食|丼|天ぷら|刺身|焼き魚|焼き鳥|ステーキ|フルーツ|果物|野菜|卵|豆腐|チーズ|ヨーグルト|おいしい|美味しい|うまい|食べたい|お腹すいた|お腹がすいた|腹ペコ|空腹|満腹|もぐもぐ|ぱくぱく|food|meal|meals|delicious|yummy|tasty|cooking|recipe|recipes|restaurant|breakfast|lunch|dinner|snack|snacks|pizza|ramen|sushi|curry|cake|dessert|coffee|hungry|starving)/i;

// ===== AI驚き屋を「見ない」モード =====
// AIの能力・脅威を誇張して不安や驚きを煽る投稿（AI驚き屋）の候補シグナル。
// Jev が最終判断し、客観的なAIニュース・ツール紹介・作品・技術解説・冷静な議論は除外する。
const AI_HYPE_SIGNAL = /(?:シンギュラリティ|特異点|技術的特異点|汎用人工知能|超知能|スーパーAI|\bASI\b|AIが人類|人類滅亡|人類は終わ|人類終了|AIに支配され|AIが支配|AIが仕事を奪|AIで失業|AI失業|AI大量失業|AIが全てを|AIの暴走|AI暴走|AIが自我|AIが意識|AIが覚醒|AIが反乱|ロボットが支配|AI兵器|AI戦争|AI終了|日本終了|世界終了|AIが人間を超|AIが人間を淘汰|AIが取って代わ|AIで世界が終|AIパニック|人工知能が人類|AIが進化しすぎ|AIの進化が止まらない|数年以内に人類|あと数年で人類|AIが全ての仕事|AIが全職業|AIが全人類|AIが人間の仕事|AIに置き換えられ|AI失業時代|AIによる大量失業|AIが人類を超える|AIが人間を支配|AIが地球を|AIが全知全能|AI神|AIが神に|人工知能の暴走|\bAGI\b|GPT-?[56]|singularity|superintelligence|super intelligence|AI takeover|AI apocalypse|AI doom|AI will take over|AI takes over|AI replacing humans|AI replacing jobs|AI job losses|AI uprising|robot uprising|killer robots|autonomous weapons|AI sentient|AI consciousness|AGI imminent|AGI achieved|AGI is here|end of humanity|human extinction|AI extinction|AI dominates|AI singularity|AI god|AI becomes god)/i;

// ===== アカウント非表示モード =====
// 「政府・政治家アカウントを隠す」/「ニュースアカウントを隠す」ON時に完全非表示にする @ハンドル一覧
const GOV_ACCOUNTS = new Set([
  // 米国
  "potus", "vp", "whitehouse", "joebiden", "barackobama", "kamalaharris",
  "hillaryclinton", "berniesanders", "aoc", "senwarren", "senschumer",
  "leaderhakeemjeffries", "gopleader", "housegop", "senategop", "gop",
  "dnc", "housedemocrats", "senatedems", "tedcruz", "marcorubio", "randpaul", "speakerjohnson",
  // 英国
  "10downingstreet", "rishisunak", "keir_starmer", "uklabour", "conservatives", "borisjohnson",
  // フランス
  "elysee", "emmanuelmacron", "gouvernementfr",
  // ドイツ
  "bundeskanzler", "olafscholz", "bundesregierung",
  // イタリア
  "giorgiameloni",
  // カナダ
  "justinptrudeau", "canadianpm",
  // インド
  "narendramodi", "pmoindia",
  // 日本（首相官邸・与党・国会など）
  "kantei", "kishida230", "jimin_koho", "shugiin_japan", "sangiin_japan", "mofajapan_jp", "mextjapan",
  // ウクライナ
  "zelenskyyua", "ukraine", "denys_shmyhal",
  // ロシア
  "kremlinrussia_e", "mfa_russia",
  // イスラエル
  "netanyahu", "israelipm", "israelmfa", "israel",
  // 中国
  "mfa_china", "china_spokesperson",
  // 国際機関
  "nato", "un", "eu_commission"
]);

const NEWS_ACCOUNTS = new Set([
  // 日本のニュース
  "nhk_news", "kyodo_official", "jijicom", "asahicom", "yomiuri_online",
  "mainichi", "sankei_news", "nikkei", "thejapantimes", "afpbbnews",
  "bbcnewsjapan", "cnn_co_jp", "reuters_japan", "wsjjapan", "bloombergjapan",
  "tbsnews", "news_tbs", "tv_asahi_news", "fnn_news",
  // 世界のニュース
  "cnn", "cnnbreaking", "bbcbreaking", "bbcworld", "bbcnews",
  "nytimes", "washingtonpost", "wsj", "reuters", "ap", "afp",
  "aljazeera", "ajenglish", "skynews", "guardian", "theguardian",
  "independent", "telegraph", "financialtimes", "economist", "time", "newsweek",
  "foxnews", "msnbc", "abcnews", "cbsnews", "nbcnews", "pbsnews", "bloomberg",
  "dwnews", "dw_english", "france24", "rf_english",
  "straits_times", "scmp", "hindustantimes", "thehindu", "timesofindia",
  "channel4news", "itvnews"
]);

// ===== 金融・経済アカウント非表示モード =====
// 「金融アカウントを隠す」ON時に完全非表示にする @ハンドル一覧
const FIN_ACCOUNTS = new Set([
  // 世界の金融メディア
  "wsj", "financialtimes", "ft", "bloomberg", "cnbc", "marketwatch",
  "businessinsider", "business", "fortunemagazine", "forbes", "economist",
  "investingcom", "thestreet", "barronsofficial",
  // 日本の金融メディア
  "nikkei", "nikkei_plus", "nikkei_news", "marketecom",
  // 中央銀行・金融当局・国際機関
  "federalreserve", "ecb", "bankofengland", "bankofcanada", "bankofjapan_en",
  "imf", "worldbank", "us_treasury",
  // 仮想通貨・ブロックチェーン
  "cointelegraph", "coindesk", "bitcoin", "theblock__", "cryptopotato",
  "watcherguru", "u.today", "coinjournal",
  // マーケット・アナリスト
  "zerohedge", "stocktwits", "markets" 
]);

// ===== アートモード（スペシャル）=====
// 「アート中心モード」ON時に表示を許可するアート・創作系キーワード
const ART_ALLOW = /(?:絵|イラスト|イラストレーション|イラストレーター|アート|アーティスト|作品|描いた|描き|描いて|描き方|お絵かき|スケッチ|ドローイング|デッサン|漫画|マンガ|ファンアート|デジタルアート|水彩|水彩画|油絵|アクリル画|彫刻|芸術|芸術家|画家|画廊|ギャラリー|展示|展示会|個展|絵画|アニメ|アニメーション|ドット絵|落書き|ラフ画|線画|原画|塗り絵|美術|美術館|創作者|創作|絵を描く|art|artist|artists|illustration|illustrations|illustrator|drawing|drawings|drew|sketch|sketches|painting|paintings|painted|digital art|fanart|fan art|artwork|artworks|gallery|manga|anime|sculpture|watercolor|acrylic|canvas|portrait|abstract|concept art|doodle|sketchbook|paint|artistic|creativity|creative|masterpiece)/i;

// ===== 暴言・誹謗フィルター =====
// 「暴言を隠す」ON時に非表示にする暴言・誹謗ワード
const INSULT_JP = [
  "死ね", "氏ね", "しね", "死んどけ", "死にやがれ", "くたばれ", "消えろ", "消え失せろ",
  "失せろ", "出て行け", "出てけ", "カス", "カス野郎", "クズ", "くず", "クズ野郎",
  "ゴミ野郎", "ゴミクズ", "ゴミカス", "くそ野郎", "クソ野郎", "クソ", "くそ", "バカ", "バカ野郎",
  "馬鹿", "馬鹿野郎", "アホ", "あほ", "阿呆", "ボケ", "ボケ野郎", "たわけ", "無能",
  "ド素人", "ハゲ", "禿げ", "デブ", "ブス", "チビ", "キモい", "キモイ", "気色悪い",
  "うざい", "ウザい", "うぜえ", "パクリ", "パクり", "パクった", "盗作", "盗用", "丸パクリ",
  "無断転載", "AIかよ", "AIだろ", "AIでしょ", "AIやん", "AIのくせに"
];
const INSULT_EN = [
  "die", "kys", "kill yourself", "go die", "fuck", "fucking", "fuck you",
  "asshole", "bitch", "idiot", "moron", "dumbass", "stupid", "dumb", "trash",
  "piece of shit", "loser", "pathetic", "ugly", "bald", "scum", "worthless",
  "you suck", "shut up", "retard", "whore", "bastard", "jerk", "screw you",
  "eat shit", "fool", "dipshit", "shithead", "jackass"
];
const INSULT_STRONG = new RegExp(`(?:${INSULT_JP.join("|")})|(?:${INSULT_EN.map(EN).join("|")})`, "i");
